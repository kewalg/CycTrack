package com.example.cyctrack.Model;

public class Rain {
}
